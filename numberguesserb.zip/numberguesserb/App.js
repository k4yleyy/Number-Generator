import * as React from 'react';
import { Text, View, StyleSheet, TextInput, Button } from 'react-native';

export default function App() {
  const [guess, setGuess] = React.useState(0);
   const [mystery, setMystery] = React.useState(Math.floor(Math.random()*1000));
   const [number, setNumber] = React.useState(0);
  const [result, setResult] = React.useState('Guess my number');
  const onGuess = (newGuess) => {
    setGuess(newGuess);
  }
  const onClick = () => {
       setNumber (number + 1)
    if (guess === mystery.toString()){
      setResult ("Great job, you magically guessed it correctly!")
      setMystery ((Math.floor(Math.random()*1000)))
      setNumber (0)
    }else if (guess > 999){
      setResult ("Your guess can only be 0-999 inclusive")
    }else if (guess < 0){
      setResult ("Your guess can only be 0-999 inclusive")
    }else if (guess > mystery) {
      setResult ("try a smaller number")
    }else if (guess < mystery) {
        setResult ("try a larger number")
      }
  }
 
  return (
    <View style={styles.container}>
       <Text style={styles.paragraph}>
        {result}
      </Text>
      <Text>
        Guesses: {number}
      </Text>
      <TextInput
        onChangeText={onGuess}
        value={guess}
        kayboardType="number-pad"
        style={styles.input}
      />
      <Button
      onPress={onClick}
      color="#9abbe6"
      title= "press to guess"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  input: {
    margin: 12,
    borderWidth: 1,
    padding: 10,
 
  }
});