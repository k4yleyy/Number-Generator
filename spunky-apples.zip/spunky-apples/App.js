import * as React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';
export default function App() {
  const [randnum, setRandnum] = React.useState(
    'Click button to generate random'
  );
const onGenerateRandom = () => {
  setRandnum(Math.floor(Math.random() * 100));
}
const helloWorld = () => {
  setRandnum("Hello World!")
}
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>{randnum}</Text>
      <Button
        onPress={onGenerateRandom}
        title="Generate a Random Number!"
        color="#7d9cff"
        accessibilityLabel="Click this blue button to generate a random number"
      />
      <Button
      onPress={helloWorld}
      title="say hi to the world!"
      color= "#81ff7d"

      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
