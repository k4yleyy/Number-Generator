import * as React from 'react';
import { Text, View, StyleSheet, TextInput } from 'react-native';

export default function App() {
  const [guess, setGuess] = React.useState(0);
   const [mystery, setMystery] = React.useState(Math.floor(Math.random()*1000));
   const [number, setNumber] = React.useState(0);
  const [result, setResult] = React.useState('Guess my number');
  const onGuess = (newGuess) => {
    setNumber (number + 1)
    setGuess(newGuess);
     if (newGuess === mystery.toString()){
      setResult ("Great job, you magically guessed it correctly!")
      setMystery (React.useState(Math.floor(Math.random()*1000)))
    }else if (newGuess > 999){
      setResult ("Your guess can only be 0-999 inclusive")
    }else if (newGuess < 0){
      setResult ("Your guess can only be 0-999 inclusive")
    }else if (newGuess > mystery) {
      setResult ("try a smaller number")
    }else if (newGuess < mystery) {
        setResult ("try a larger number")
      }
  }
 
  return (
    <View style={styles.container}>
       <Text style={styles.paragraph}>
        {result}
      </Text>
      <Text>
        Guesses: {number}
      </Text>
      <TextInput
        onChangeText={onGuess}
        value={guess}
        kayboardType="number-pad"
        style={styles.input}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  input: {
    margin: 12,
    borderWidth: 1,
    padding: 10,
 
  }
});
